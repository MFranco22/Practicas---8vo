# -*- coding: utf-8 -*-
"""
Created on Thu Jan 29 08:09:06 2026

@author: migue
"""


import cv2
img = cv2.imread("fondo.jpg")
img1 = cv2.imread("fondo1.png")
alto, ancho,_ = img.shape
alto1, ancho1,_ = img1.shape

if(alto + ancho)>(alto1 + alto1):
    img = cv2.resize(img, (ancho1,alto1))
else:
    img1 = cv2.resize(img1, (ancho,alto))
    #Conbinar imagenes
alpha = 0.5 #influencia de la primera imagen
beta = 0.9 # Peso de influencia de la segunda imagenm
gamma = 0 # Valor de compensación

resultado = cv2.addWeighted(img, alpha, img1, beta, gamma)
cv2.imwrite("resultado.jpg", resultado)
resultado = cv2.imread("resultado.jpg")

#cv2.namedWindow("rene",cv2.WINDOW_NORMAL) #Ajustar la imagen
cv2.imshow("Resultado", resultado)
cv2.imshow("Imagen", img)
cv2.imshow("Imagen1", img1)
cv2.waitKey(0)
cv2.destroyAllWindows()