# -*- coding: utf-8 -*-
"""
Created on Thu Jan 22 07:40:00 2026

@author: migue
"""

import cv2
import easygui as ventana #Hacer ventanas
from tkinter import messagebox

extension = ["*.jpg","*.png","*.gif"]
imagen = ventana.fileopenbox(msg = "Abrir archivo",
                          title="Buscador de Imagenes",
                          default="",
                          filetypes=extension) #Hacer ventana de FILE para elegir Imagen
print(imagen[len(imagen)-3:])
ext = imagen[len(imagen)-3:]

if ext in ["jpg","png","gif"]: # Ventana de error al no escoger una imagen
    print("Correcto")
    
    #img = cv2.imread("img2.jpg")
    img = cv2.imread(imagen)
    alto, ancho,_ = img.shape # VER LOS PIXELES DE LA IMAGEN
    print(alto, ancho)

    copia = img.copy() #Hacer copia de la imagen
    copia = cv2.resize(copia,(0,0),fx=0.5, fy=0.5) # Cambiar el tamaño de la copia
    alto2, ancho2,_=copia.shape
    print(alto2, ancho2)

    cv2.imwrite("copia.jpg",copia) #GENERAR LA COPIA
    #cv2.namedWindow("ImagenCopia",cv2.WINDOW_NORMAL) #Ajustar la imagen
    cv2.imshow("ImagenCopia", copia)

    #cv2.namedWindow("Imagen",cv2.WINDOW_NORMAL) #Ajustar la imagen
    cv2.imshow("Imagen", img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
else:
    print("Error")
    messagebox.showinfo("Error", "Imagen Incorrecta")
    

