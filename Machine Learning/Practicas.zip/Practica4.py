# -*- coding: utf-8 -*-
"""
Created on Fri Jan 23 10:43:04 2026

@author: migue
"""
import cv2
img = cv2.imread("rene.jpg")

#Recorta la imagen con estos codigos la divide
parte = img[0:,0:250] #divide imagen en horizontal y vertical
cv2.imwrite("parte.jpg", parte)
parte = cv2.imread("parte.jpg")
cv2.namedWindow("parte", cv2.WINDOW_NORMAL)
cv2.imshow("parte", parte)
print (parte) # Ver Coordenadas

#segunda mitad
parte2 = img[0:,250:] #divide imagen
cv2.imwrite("parte2.jpg", parte2)
parte2 = cv2.imread("parte2.jpg")
cv2.namedWindow("parte2", cv2.WINDOW_NORMAL)
cv2.imshow("parte2", parte2)
print (parte2)

#Ver Pixeles
alto, ancho,_ = img.shape # VER LOS PIXELES DE LA IMAGEN
print("pixeles",alto, ancho)

#Concatenamos las matrices vertical y horizontal en la lertra v_concat
dosimagenes = cv2.hconcat([parte,img,parte2]) # Unir matrices
cv2.namedWindow("ImagenUnidas",cv2.WINDOW_NORMAL) #Ajustar la imagen
cv2.imshow("ImagenUnidas", dosimagenes)

cv2.namedWindow("Imagen",cv2.WINDOW_NORMAL) #Ajustar la imagen y titulo
cv2.imshow("Imagen", img)
cv2.waitKey(0)
cv2.destroyAllWindows()















