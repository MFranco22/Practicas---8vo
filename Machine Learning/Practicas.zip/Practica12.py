# -*- coding: utf-8 -*-
"""
Created on Fri Feb  6 10:28:35 2026

@author: migue
"""

import cv2
import numpy as np
camara = cv2.VideoCapture(0)
while(camara.isOpened()):
    f, frame = camara.read()
    if f == True:
        frame = cv2.flip(frame, 1) # camniar el espejo de la camara
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        blanco1 = np.array([25,20,20])
        blanco2 = np.array([100,255,255])
        
        kernel = np.ones((7,7),np.uint8)
        mascara = cv2.inRange(hsv, blanco1, blanco2)
        mascara = cv2.morphologyEx(mascara, cv2.MORPH_CLOSE, kernel)
        mascara = cv2.morphologyEx(mascara, cv2.MORPH_OPEN, kernel)
        resultado = cv2.bitwise_and(frame, frame, mask=mascara)
        #resultado[mascara>0]=(255,255,255)
        nuevo = cv2.add(frame,resultado)
        cv2.imshow("Nuevo", nuevo)
        cv2.imshow("Resultado", resultado)
        cv2.imshow("Frame", frame)
        key = cv2.waitKey(1)
        if key == ord('a'):
            break
    else:
        break
camara.release()
cv2.destroyAllWindows()