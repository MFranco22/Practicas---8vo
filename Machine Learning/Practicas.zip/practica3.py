# -*- coding: utf-8 -*-
"""
Created on Fri Jan 23 10:28:41 2026

@author: migue
"""

import cv2

img = cv2.imread("img2.jpg")
img2 = img.copy()
img2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

cv2.imwrite("Gris.jpg", img2)
img2 = cv2.imread("Gris.jpg")
#cv2.namedWindow("Gris",cv2.WINDOW_NORMAL) #Ajustar la imagen
#cv2.imshow("Gris", img2)

#Concatenamos las matrices vertical y horizontal en la lertra v_concat
dosimagenes = cv2.hconcat([img,img2]) # Unir matrices
cv2.namedWindow("Imagen",cv2.WINDOW_NORMAL) #Ajustar la imagen
cv2.imshow("Imagen", dosimagenes)

cv2.waitKey(0)
cv2.destroyAllWindows()