# -*- coding: utf-8 -*-
"""
Created on Thu Jan 22 09:37:38 2026

@author: migue
"""

#Visualizar imagenes en forma de R G B
import cv2
img = cv2.imread("rene.jpg")
copia = img.copy()
img2 = cv2.cvtColor(copia, cv2.COLOR_BGR2HSV)


H,S,V = cv2.split(img)

cv2.namedWindow("H",cv2.WINDOW_NORMAL) #Ajustar la imagen
cv2.imshow("H", H)
cv2.namedWindow("S",cv2.WINDOW_NORMAL) #Ajustar la imagen
cv2.imshow("S", S)
cv2.namedWindow("V",cv2.WINDOW_NORMAL) #Ajustar la imagen
cv2.imshow("V", V)

cv2.imwrite("copia.jpg",copia) #GENERAR LA COPIA
#cv2.namedWindow("ImagenCopia",cv2.WINDOW_NORMAL) #Ajustar la imagen
cv2.imshow("ImagenCopia", copia)


"""
R,G,B = cv2.split(img)

cv2.namedWindow("R",cv2.WINDOW_NORMAL) #Ajustar la imagen
cv2.imshow("R", R)
cv2.namedWindow("G",cv2.WINDOW_NORMAL) #Ajustar la imagen
cv2.imshow("G", G)
cv2.namedWindow("B",cv2.WINDOW_NORMAL) #Ajustar la imagen
cv2.imshow("B", B)
"""


cv2.waitKey(0)
cv2.destroyAllWindows()