# -*- coding: utf-8 -*-
"""
Created on Thu Feb  5 08:29:10 2026

@author: migue
"""
#LEER VIDEOS

import cv2
from moviepy import VideoFileClip
import pygame


videoReal = "gangle.mp4"

videoR = VideoFileClip(videoReal)
audio = videoR.audio   

pygame.mixer.init()
audio.write_audiofile("temp_audio.wav")
pygame.mixer.music.load("temp_audio.wav")
pygame.mixer.music.play()
video = cv2.VideoCapture(videoReal)
fps = video.get(cv2.CAP_PROP_FPS)

tiempo = int(500 / fps)

while True:
    f, frame = video.read()
    if f:
        cv2.namedWindow("FRAME", cv2.WINDOW_NORMAL)
        cv2.imshow("FRAME", frame)
        if cv2.waitKey(tiempo) & 0xFF == ord('a'):
            break
    else:
        break

video.release()
cv2.destroyAllWindows()

