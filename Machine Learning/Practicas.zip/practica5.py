# -*- coding: utf-8 -*-
"""
Created on Thu Jan 29 07:29:08 2026

@author: migue
"""
#RECORTAR IMAGEN CON EL MAUSE

import cv2
img1 = cv2.imread("rene.jpg")
img = img1.copy()
roi = cv2.selectROI("ROI", img)
nuevaImagen = img[int(roi[1]):int(roi[1]+roi[3]),int(roi[0]): #EL ROI FUNCIONA PARA RECORTAR LA IMAGEN CON EL MAUSE
                  int(roi[0]+roi[2])]
    
alto, ancho,_ = nuevaImagen.shape
nuevaImagen = cv2.resize(nuevaImagen,(ancho,alto))
cv2.imwrite("recorte.jpg",nuevaImagen) #guardar el recorte
recorte = cv2.imread("recorte.jpg")

R,G,B = cv2.split(recorte) #Separamos los canales de RGB
while(True):
    if cv2.waitKey(1) & 0xFF == ord ('a'):
        print("Presionaste la Letra A")
        cv2.imshow("R", R)
    if cv2.waitKey(1) & 0xFF == ord ('s'):
        print("Presionaste la Letra S")q
        cv2.imshow("G", G)
    if cv2.waitKey(1) & 0xFF == ord ('d'):
        print("Presionaste la Letra D")
        cv2.imshow("B", B)
    if cv2.waitKey(1) & 0xFF == ord ('q'):
        print("Salir")
        break
      
#cv2.namedWindow("Imagen",cv2.WINDOW_NORMAL) #Ajustar la imagen
#cv2.imshow("Recorte", recorte)
#cv2.imshow("Imagen", img)
cv2.waitKey(0)
cv2.destroyAllWindows()