import cv2
import pytesseract # type: ignore
import pyttsx3 # type: ignore

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

texto = cv2.imread("im1.jpg")
texto = cv2.resize(texto,None, fx=2, fy=2,interpolation=cv2.INTER_CUBIC)

gris = cv2.cvtColor(texto, cv2.COLOR_BGR2GRAY)
gris = cv2.GaussianBlur(gris, (5,5), 0)
_, resp = cv2.threshold(gris, 150, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

config = '--psm 6'
salida = pytesseract.image_to_string(resp, lang= 'eng')
print(salida)