# -*- coding: utf-8 -*-
"""
Created on Fri Apr 24 10:27:27 2026

@author: migue
"""

import json 

datos ={
        "abre":{
            "calculadora" : "calc.exe",
            "bloc de notas" : "notepad.exe",
            "paint" : "mspaint.exe"
            
            }
        }
with open("comando.json","w",encoding="utf-8") as archivo:
    json.dump(datos,archivo,indent=4,ensure_ascii=False)
    