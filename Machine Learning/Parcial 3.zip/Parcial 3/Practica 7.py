# -*- coding: utf-8 -*-
"""
Created on Fri May  8 11:08:23 2026

@author: migue
"""

import cv2
import mediapipe as mp
import numpy as np

img = cv2.imread("lentes.png", cv2.IMREAD_UNCHANGED)

mp_face_mesh = mp.solutions.face_mesh
face_ojos = mp_face_mesh.FaceMesh(refine_landmarks=True)
camara = cv2.VideoCapture(0)

while True:
    r, frame = camara.read()
    if not r:
        break
    frame = cv2.flip(frame, 1)
    
    alto, ancho,_=frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    resultado = face_ojos.process(rgb)
    
    if resultado.multi_face_landmarks:
        for rostro in resultado.multi_face_landmarks:
            #33 263
            ojo_izq = rostro.landmark[33]
            ojo_der = rostro.landmark[263]
            x1 = int(ojo_izq.x * ancho)
            y1 = int(ojo_izq.y * alto)
            
            x2 = int(ojo_der.x * ancho)
            y2 = int(ojo_der.y * alto)
            distancia = int(np.sqrt((x2-x1)**2 + (y2-y1)**2))
            ancho_lentes = int(distancia * 2)
            
            alto_lentes = int(ancho_lentes * img.shape[0] / img.shape[1])
            
            lentes_ajustar = cv2.resize(img,
                                        (ancho_lentes,alto_lentes))
            
            x= int((x1 + x2)/2 - ancho_lentes /2)
            y= int((y1+y2)/2 -alto_lentes / 2)
            
            if x < 0:
                x = 0
            if y < 0:
                y = 0
            
            if lentes_ajustar.shape[2] == 4:
                imgT = lentes_ajustar[:,:,:3]
                
                mascara = lentes_ajustar[:,:,3] / 255.0
                h, w, _ = imgT.shape
                
                if y + h < alto and x + w < ancho:
                    roi = frame[y:y+h, x:x+w]
                
                    for c in range(3):
                        roi[:,:,c] = (imgT[:,:,c] * mascara + roi[:,:,c] * (1-mascara))
                        
                    frame[y:y+h, x:x+w] = roi
                

    cv2.imshow("Filtro",frame)
    if cv2.waitKey(1) & 0xFF ==  ord('q'):
        break

camara.release()
cv2.destroyAllWindows()