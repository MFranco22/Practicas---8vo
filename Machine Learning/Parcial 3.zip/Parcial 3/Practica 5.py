# -*- coding: utf-8 -*-
"""
Created on Thu May  7 07:41:58 2026

@author: migue
"""
import cv2
import face_recognition
import pyttsx3

caras = []
nombres = []

def HablarIA(texto):
    print(texto)
    hablar = pyttsx3.init()
    voces = hablar.getProperty('voices')
    velocidad = hablar.getProperty('rate')
    hablar.setProperty('rate',velocidad - 800)
    hablar.setProperty('voice',voces[2].id)
    hablar.say(texto)
    hablar.runAndWait()

persona1 = face_recognition.load_image_file('fernanfloo.jpg')
persona2 = face_recognition.load_image_file('cochil.jpg')
persona3 = face_recognition.load_image_file('franco.jpeg')

if face_recognition.face_encodings(persona1):
    persona1enontrada = face_recognition.face_encodings(persona1)[0]
    caras.append(persona1enontrada)
    nombres.append('Fernanfloo')

if face_recognition.face_encodings(persona2):
    persona2enontrada = face_recognition.face_encodings(persona2)[0]
    caras.append(persona2enontrada)
    nombres.append('Cochil Galvez')
    
if face_recognition.face_encodings(persona3):
    persona3enontrada = face_recognition.face_encodings(persona3)[0]
    caras.append(persona3enontrada)
    nombres.append('Frankito melocoton ')
    
camara = cv2.VideoCapture(0)
while True:
    r, frame = camara.read()
    if not r:
        break
    carasEncontradas = face_recognition.face_locations(frame)
    caras_codes_frame = face_recognition.face_encodings(frame, carasEncontradas)
    for(arriba, derecha, abajo, izquierda),caras_codes in zip(carasEncontradas, caras_codes_frame):
        puntos = face_recognition.compare_faces(caras, caras_codes)
        nombre = "sin nombre"
        if True in puntos:
            primerpunto = puntos.index(True)
            nombre = nombres[primerpunto]
        cv2.rectangle(frame,(izquierda,arriba), (derecha, abajo), (0,255,0), 2)
        HablarIA(f'El nombre de la pichulita encontrada es {nombre}')
        
        
        cv2.imshow("frame", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

camara.release()
cv2.destroyAllWindows()    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

