import speech_recognition as sr 
import pyttsx3
import pyjokes
import pywhatkit
import pyautogui
import os 
import wikipedia
from datetime import datetime
import cv2
import json
import subprocess



listener = sr.Recognizer()
'''hablar = pyttsx3.init()
voces = hablar.getProperty('voices')
hablar.setProperty('voice',voces[0].id)#el idioma de la voz
velocidadVoz=hablar.getProperty('rate')
hablar.setProperty('rate',velocidadVoz-50)#esta es la velocidad para la voz de como habla '''

def escucharIA():
    while True:
        with sr.Microphone() as source:
            print("Escuchando...")
            audio = listener.listen(source, phrase_time_limit=5)#cuanto tiempo tiene para seguir esuchando
            try:
                print('Reconociendo.....')
                text = listener.recognize_google(audio, language='es-US').lower()
                break
            except Exception as e:
                print('No te entendi we')
                HablarIA('No te entendi we')
    return text
    
                
def HablarIA(texto):
    print(texto)
    engine = pyttsx3.init()  # 🔥 reiniciar motor cada vez
    voces = engine.getProperty('voices')
    engine.setProperty('voice', voces[0].id)
    
    velocidadVoz = engine.getProperty('rate')
    engine.setProperty('rate', velocidadVoz - 50)
    
    engine.say(texto)
    engine.runAndWait()

def DecirChiste():
    chiste = pyjokes.get_joke(language='es',category='neutral')
    HablarIA(chiste)

def BuscarYoutube(comando):
    #buscar = comando.replace('buscar en youtube', '').strip()
    op = comando.find('youtube')
    buscar = comando[op+8:]
    print(buscar)
    pywhatkit.search(buscar)
       
def BuscarGoogle(comando):
    buscar = ''   
    print('google')
    op = comando.find('google')
    buscar = comando[op+7:]
    print(buscar)
    pywhatkit.search(buscar)

def BuscarWiki(comando):
    wikipedia.set_lang('es')
    op = comando.find('wikipedia')
    buscar = comando[op+10:]
    print(buscar)
    resultado = wikipedia.summary(buscar,sentences=3)
    HablarIA(resultado)
    
def DecirHora(comando):
    print(f"La Hora es {datetime.datetime.now().strftime('%H:%M')}")
    HablarIA(f"La Hora es {datetime.datetime.now().strftime('%H:%M')}")
    
def DecirFecha(comando):
    print(f"la fecha es{datetime.now().date()}")
    HablarIA(f"la fecha es{datetime.now().date()}")

    
def CapturarPantalla(comando):
    HablarIA('Capturando pantalla, despues deberas cerrar la ventana para poder continuar')
    captura = pyautogui.screenshot()
    nombre = 'C://Users/migue/Documents/captura'+datetime.now().strftime('%H:%M')+'.jpg'
    captura.save(nombre)
    img = cv2.imread(nombre)
        
    cv2.namedWindow('Captura', cv2.WINDOW_NORMAL)
    cv2.imshow('Captura', img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
def ComandosJson(comando):
    with open ("comando.json","r",encoding="utf-8") as archivo:
        datos = json.load(archivo)
    
    if 'abre' in comando or 'abrir' in comando:
        for index in datos['abre']:
            if index in comando:
                programa = datos['abre'][index]
                subprocess.Popen(programa)
                break            


        
HablarIA('Hola MI cara de perro................... que vas a ladrar hoy')

while True:
    comando = None
    comando = escucharIA()
    print(comando) 
    if 'chiste' in comando:
        DecirChiste()  
        
    if'youtube' in comando:
        BuscarYoutube(comando)
        break
    
    if'google' in comando:
        BuscarGoogle(comando)
        break
    
    if'wikipedia' in comando:
        BuscarWiki(comando)
        break
    if 'la hora' in comando:
        DecirHora(comando)
        break
    
    if'la fecha' in comando:
        DecirFecha(comando)
        break
    
    if 'captura pantalla' in comando:
        CapturarPantalla(comando)
        break
    
    if'abrir' in comando or 'abre' in comando:
        ComandosJson(comando)
        break
    
        
    #Hablar Comando
    HablarIA(comando)
    if comando =='salir':
        HablarIA("Hasta la vista")
        break