import cv2
import mediapipe as mp
import numpy as np
import math

mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

def contardedos():
    camara = cv2.VideoCapture(0)
    holistic = mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5)
    while True:
        r, frame = camara.read()
        if not r:
            break
        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        resultados = holistic.process(rgb)
        
        #mano izquierda
        mp_drawing.draw_landmarks(frame, resultados.left_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
                                mp_drawing.DrawingSpec(color=(80, 22, 10), thickness=2, circle_radius=4),
                                mp_drawing.DrawingSpec(color=(80, 44, 121), thickness=2, circle_radius=2))
        #mano derecha
        mp_drawing.draw_landmarks(frame, resultados.right_hand_landmarks, mp_holistic.HAND_CONNECTIONS,
                                mp_drawing.DrawingSpec(color=(80, 22, 10), thickness=2, circle_radius=4),
                                mp_drawing.DrawingSpec(color=(80, 44, 121), thickness=2, circle_radius=2))
        
        if resultados.left_hand_landmarks or resultados.right_hand_landmarks:
            dedos = 0
            
            if resultados.left_hand_landmarks:
                dedos += contar(resultados.left_hand_landmarks.landmark)

            if resultados.right_hand_landmarks:
                dedos += contar(resultados.right_hand_landmarks.landmark)

            cv2.putText(frame, f"Dedos: {dedos}", (100, 100), cv2.FONT_HERSHEY_SIMPLEX, 3, (0, 255, 0), 3)
            print(f"Dedos: {dedos}")
        
        cv2.imshow("frame", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        
    camara.release()
    cv2.destroyAllWindows()
def contar(hand_landmarks):
    dedos_indices = [8, 12, 16, 20]
    muneca = hand_landmarks[0]
    dedoscontar = 0
    pulgar = calculardistancia(hand_landmarks[4], muneca)
    if pulgar > 0.25:
        dedoscontar += 1
    for dedo in dedos_indices:
        dedo_landmark = hand_landmarks[dedo]
        dedo_distancia = calculardistancia(dedo_landmark, muneca)
        if dedo_distancia > 0.3:
            dedoscontar += 1
    return dedoscontar

def calculardistancia(puntodedo, puntomuneca):
    x1, y1, z1 = puntodedo.x, puntodedo.y, puntodedo.z
    x2, y2, z2 = puntomuneca.x, puntomuneca.y, puntomuneca.z
    pulgar = math.sqrt((x2 - x1)*2 + (y2 - y1)2 + (z2 - z1)*2)
    return pulgar
    
if _name_ == "_main_":
    contardedos()