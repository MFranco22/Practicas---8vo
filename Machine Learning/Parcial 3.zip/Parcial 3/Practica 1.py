import cv2
import pytesseract # type: ignore
import pyttsx3 # type: ignore

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe" 

texto = cv2.imread("texto4.jpg")
gris = cv2.cvtColor(texto, cv2.COLOR_BGR2GRAY)
salida = pytesseract.image_to_string(gris)
print(salida)
voz = pyttsx3.init()
voces = voz.getProperty('voices')
voz.setProperty('rate',130)
voz.setProperty('volume',2)
voz.setProperty('voice',voces[0].id)
voz.say(salida)
voz.runAndWait()