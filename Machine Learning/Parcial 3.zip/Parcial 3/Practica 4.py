# -- coding: utf-8 --
"""
Created on Thu Apr 30 08:18:48 2026

"""


from openai import OpenAI

import speech_recognition as sr 
import pyttsx3
import pyjokes
import pywhatkit
import pyautogui
import os
import wikipedia
from datetime import datetime
import cv2
import easygui as vent 
import json
import random
import subprocess



listener = sr.Recognizer()
#hablar.say('Hola mundo')
#hablar.runAndWait()

def escucharIA():
    while True:
        with sr.Microphone() as source:
            print('Escuchando...')
            audio = listener.listen(source, phrase_time_limit=5)
            try:
                print('Reconocimiento...')
                text = listener.recognize_google(audio, language='es-US').lower()
                print(text)
                break
            except Exception as e:
                print('No te entendí:', e)
                HablarIA('No te entendí, repítelo')
    return text
   
                
def HablarIA(texto):
    print(texto)
    hablar = pyttsx3.init()
    voces = hablar.getProperty('voices')
    velocidad = hablar.getProperty('rate')
    hablar.setProperty('rate',velocidad - 500)
    hablar.setProperty('voice',voces[0].id)
    hablar.say(texto)
    hablar.runAndWait()

def Bienvenida():
    HablarIA('Hola, en que le ayudo')

def DecirChiste():
    chiste = pyjokes.get_joke(language='es', category='neutral')
    HablarIA(chiste)
client = OpenAI(api_key="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")


def buscarIA(comando):
    respuesta = client.chat.completions.create(
        model = 'gpt-4o-mini',
        messages=[
            {"role":"user","content":comando}
             ]
           )
    return respuesta.choices[0].message.content
    
    
def ComandosJson(comando):
    with open("comando.json", "r", encoding="utf-8") as archivo:
        datos = json.load(archivo)
        
    if 'abre' in comando or 'abrir' in comando:
        for index in datos['abre']:
            if index in comando:
                programa = datos['abre'][index]
                subprocess.Popen(programa)
                break
            
    
    

while True:
    print('primer ciclo')
    comando = escucharIA()
    #print(comando)
    if 'ceviche' in comando:
        HablarIA('Hola, en que puede ayudarte')
        while True:            
            print('segundo ciclo')
            comando = None
            comando = escucharIA()
            if 'chiste' in comando:
                DecirChiste()
                break
            if"buscar" in comando or "busca" in comando or"que es" in comando or "investiga" in comando:
                respuesta = buscarIA(comando)
                HablarIA(respuesta)
                break
            else:
                respuesta = buscarIA(comando)
                HablarIA(respuesta)
                break
    break
            
    
    #HablarIA(comando)
    if  comando == 'salir':
        HablarIA('hasta luego')
        break