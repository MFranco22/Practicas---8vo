import cv2
import easygui as vent


def extraercaractersiticas(imagen):
    img=cv2.imread(imagen)
    img=cv2.resize(img,(600,600))
    copia=img.copy()
    copia=cv2.cvtColor(copia,cv2.COLOR_BGR2GRAY)
    sift=cv2.SIFT_create(nfeatures=150)
    pr,d= sift.detectAndCompute(copia,None)
    
    return img,pr,d
def compararImagenes(pr,d,pr2,d2):
    bf=cv2.BFMatcher()
    coinsidencias= bf.knnMatch(d,d2,k=2)
    caracteristicas=[]
    for a in coinsidencias:
        if len (a)==2:
            c,b = a
            if c.distance <0.6* b.distance:
                caracteristicas.append(c) 
    if max(len(pr),len(pr2))>0:
        similitud=len(caracteristicas)/min(len(pr),len(pr2))
    else:
        similitud=0
    return similitud, caracteristicas
    

    
imagen1 = vent.fileopenbox(msg="Abrir Imagen", title="Abrie",
                           default="",filetypes=["*.jpg"])

img,pr,d=extraercaractersiticas(imagen1)
#img1 = cv2.imread(imagen1)

imagen2 = vent.fileopenbox(msg="Abrir Imagen", title="Abrie",
                           default="",filetypes=["*.jpg"])


img2,pr2,d2=extraercaractersiticas(imagen2)

if img is None or img2 is None:
    print("Error al cargar imagen")
else:
    similitud,caracteristicas= compararImagenes(pr,d,pr2,d2)
    
    print("puntos de referencia imagen 1",len(pr))
    print("puntos de referencia imagen 2",len(pr2))
    print("Caracteristicas",len(caracteristicas))
    print("similitudes",similitud)
    resultado=cv2.drawMatches(img,pr,img2,pr2,caracteristicas,None,flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
    
    
    texto = f"Similitud: {similitud:.2f}"
    
    if similitud >0.5 and len(caracteristicas)>30:
        print("son el mismo objeto")
    else:
        print("No son el mismo objeto ")
        
        cv2.putText(
        resultado,
        texto,
        (50, 50),
        cv2.FONT_HERSHEY_SIMPLEX,
        1,
        color,
        2,
        cv2.LINE_AA
    )

    
    
"""
if img is None or img2 is None:
    print("Error al cargar imagen")
else:
    similitud, caracteristicas       = compararImagenes(pr, d, pr2, d2)
    
    print("puntos de referencia imagen 1", len(pr))
    print("puntos de referencia imagen 2", len(pr2))
    print("Caracteristicas", len(caracteristicas))
    print("similitudes", similitud)

    resultado = cv2.drawMatches(
        img, pr, img2, pr2, caracteristicas, None,
        flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS
    )

    texto = f"Similitud: {similitud:.2f}"

    if similitud > 0.5 and len(caracteristicas) > 30:
        print("Son el mismo objeto")
    else:
        print("No son el mismo objeto")


    cv2.putText(resultado,texto,(50, 50),
                cv2.FONT_HERSHEY_SIMPLEX,1,color,2,cv2.LINE_AA            
    )

"""
        
        
    
#img2 = cv2.imread(imagen2)
cv2.namedWindow("Resultado",cv2.WINDOW_NORMAL)
cv2.imshow("Resultado", resultado)
cv2.namedWindow("imagen1",cv2.WINDOW_NORMAL)
cv2.imshow("imagen1", img)
cv2.namedWindow("imagen2",cv2.WINDOW_NORMAL)
cv2.imshow("imagen2", img2)
cv2.waitKey()
cv2.destroyAllWindows()