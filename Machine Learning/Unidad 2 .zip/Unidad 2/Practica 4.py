# -*- coding: utf-8 -*-
"""
Created on Thu Feb 26 09:30:02 2026

@author: migue
"""

import cv2
import easygui as vent
import numpy as np

def encontrarContorno(img):
    img = cv2.imread(img)
    img = cv2.resize(img, (600,600))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) #PONER IMAGEN A ESCALA DE GRISES
      
    _, valor = cv2.threshold(img, 200, 255, cv2.THRESH_BINARY)##### ESTE EL KERNEL EL GAUSSIANBLUR Y AREA LISTA SE MUEVEN
    kernel = np.ones((5,5),np.uint8) #Buscara la figura del objeto
    figura = cv2.morphologyEx(valor, cv2.MORPH_CLOSE, kernel) #Morfologia
    #bordes = cv2.Canny(figura,3,3)
    contornos, _ = cv2.findContours(figura,
                                    cv2.RETR_EXTERNAL,
                                    #cv2.RETR_TREE,
                                    cv2.CHAIN_APPROX_SIMPLE) #Generar contornos
    
    if len(contornos) == 0:
        return None, img
    
    contornoprincipal=max(contornos, key=cv2.contourArea)
    return contornoprincipal, img

imagen1 = vent.fileopenbox(msg="Abrir Imagen", title="Abrir",  #ABRIR EXPLORADOR PARA CARGAR LA IMAGEN
                           default="", filetypes=["*.jpg"])
contorno1, img1 = encontrarContorno(imagen1)

imagen2 = vent.fileopenbox(msg="Abrir Imagen", title="Abrir",  #ABRIR EXPLORADOR PARA CARGAR LA IMAGEN
                           default="", filetypes=["*.jpg"])
contorno2, img2 = encontrarContorno(imagen2)

if contorno1 is None or contorno2 is None:
    print("Alguna imagen no encontro el contorno")
    
else:
    similitud = cv2.matchShapes(contorno1, contorno2, cv2.CONTOURS_MATCH_I1, 0)
    
    if similitud < 0.01:
        print(' Los Objetos son Iguales')
    else:
        print('Los Objetos no son iguales')

cv2.namedWindow("Imagen1",cv2.WINDOW_NORMAL) 
cv2.imshow("Imagen1", img1)
cv2.namedWindow("Imagen2",cv2.WINDOW_NORMAL) 
cv2.imshow("Imagen2", img2)
cv2.waitKey()
cv2.destroyAllWindows()