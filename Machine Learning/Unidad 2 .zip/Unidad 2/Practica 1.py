# -*- coding: utf-8 -*-
"""
Created on Thu Feb 19 07:45:20 2026

@author: migue
"""
from tkinter import messagebox
import cv2
import easygui as vent

ib = False
ig = False
im = False
ie = False
imagen = vent.fileopenbox(msg="Abrir Imagen", title="Abrir",  #ABRIR EXPLORADOR PARA CARGAR LA IMAGEN
                           default="", filetypes=["*.jpg"])
img = cv2.imread("monedas.jpg")

#BLUR
imgblur = cv2.blur(img,(16,16))
cv2.namedWindow("VentanaBlur",cv2.WINDOW_NORMAL) 
cv2.imshow("VentanaBlur", imgblur)

#GAUS
imgGaus = cv2.GaussianBlur(img, (5,5),6)
cv2.namedWindow("VentanaGaus",cv2.WINDOW_NORMAL) 
cv2.imshow("VentanaGaus", imgGaus)

#MEDIAN
imgmedian = cv2.medianBlur(img, 5)
cv2.namedWindow("VentanaMedian",cv2.WINDOW_NORMAL) 
cv2.imshow("VentanaMedian", imgmedian)

#EqualizeHist
imggris = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
imgequa = cv2.equalizeHist(imggris)
cv2.namedWindow("VentanaEqua",cv2.WINDOW_NORMAL)
cv2.imshow("VentanaEqua", imgequa)

#Imagen Normal img
cv2.namedWindow("Ventana",cv2.WINDOW_NORMAL) 
cv2.imshow("Ventana", img)

while True:
    key = cv2.waitKey()

    if key == ord("b") and ib == False:
        archivo = vent.filesavebox(msg="Guardar Imagen Blur", title="Guardar Blur", #GUARDAR LAS IMAGENES
                                   default="", filetypes=["*.jpg"])
        ib = True
        cv2.imwrite(archivo, imgblur)
        vent.msgbox(msg="Imagen Guardada",title="Correcto")
    elif key == ord("b") and ib == True:
        vent.msgbox(msg="La Imagen ya se Guardo",title="Error")
        
    if key == ord("g")and ig == False:
        archivo = vent.filesavebox(msg="Guardar Imagen Gaus", title="Guardar Gaus", 
                                   default="", filetypes=["*.jpg"])
        ig = True
        cv2.imwrite(archivo, imgGaus)
        vent.msgbox(msg="Imagen Guardada",title="Correcto")
    elif key == ord("m") and im == True:
        vent.msgbox(msg="La Imagen ya se Guardo",title="Error")
        
    if key == ord("m")and im == False:
        archivo = vent.filesavebox(msg="Guardar Imagen Median", title="Guardar Median", 
                                   default="", filetypes=["*.jpg"])
        im = True
        cv2.imwrite(archivo, imgmedian)
        vent.msgbox(msg="Imagen Guardada",title="Correcto")
    elif key == ord("m") and im == True:
        vent.msgbox(msg="La Imagen ya se Guardo",title="Error")
        
    if key == ord("e")and ie == False:
        archivo = vent.filesavebox(msg="Guardar Imagen Equa", title="Guardar Equa", 
                                   default="", filetypes=["*.jpg"])
        ie = True
        cv2.imwrite(archivo, imgequa)
        vent.msgbox(msg="Imagen Guardada",title="Correcto")
    elif key == ord("e") and ie == True:
        vent.msgbox(msg="La Imagen ya se Guardo",title="Error")
        
    if key == ord("s"):
        vent.msgbox(msg="Salir",title="Correcto")
        break
    
        
        
cv2.waitKey()
cv2.destroyAllWindows()