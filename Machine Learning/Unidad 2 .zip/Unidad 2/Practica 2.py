# -*- coding: utf-8 -*-
"""
Created on Thu Feb 19 09:18:31 2026

@author: migue
"""
import cv2
import easygui as vent
import numpy as np
imagen = vent.fileopenbox(msg="Abrir Imagen", title="Abrir",  #ABRIR EXPLORADOR PARA CARGAR LA IMAGEN
                           default="", filetypes=["*.jpg"])

img = cv2.imread(imagen)
copia = img.copy()
copia = cv2.cvtColor(copia, cv2.COLOR_BGR2GRAY) #PONER IMAGEN A ESCALA DE GRISES
copia = cv2.GaussianBlur(copia, (9,9),0)
#De la imagen cada pixel que encuentre a 200, lo convierte a Blanco y el que no lo hace color negro
_, valor = cv2.threshold(copia, 250, 255, cv2.THRESH_BINARY)##### ESTE EL KERNEL EL GAUSSIANBLUR Y AREA LISTA SE MUEVEN

kernel = np.ones((9,9),np.uint8) #Buscara la figura del objeto
figura = cv2.morphologyEx(valor, cv2.MORPH_CLOSE, kernel)
bordes = cv2.Canny(figura,3,3)

contornos, _ = cv2.findContours(bordes,
                                cv2.RETR_EXTERNAL,
                                cv2.CHAIN_APPROX_SIMPLE) #Generar contornos
#cv2.drawContours(img, contornos,    
                 #-1,(0,255,0),2) #GENERAR EL GROSOR 
 
#THRESHOLD EL KERNEL EL GAUSSIANBLUR Y AREA LISTA SE MUEVEN
lista = []
for i in range(len(contornos)):
    area = cv2.contourArea(contornos[i])
    if area > 13000:
        print(area)
        cv2.drawContours(img, contornos[i],
                         -1,(0,255,2),5) #GENERAR EL GROSOR 
        lista.append(area)
print(f"Los objetos son{len(lista)}")
        
        
cv2.namedWindow("Canny",cv2.WINDOW_NORMAL) 
cv2.imshow("Canny", bordes)
cv2.namedWindow("VentanaGris",cv2.WINDOW_NORMAL) 
cv2.imshow("VentanaGris", copia)
cv2.namedWindow("Ventana",cv2.WINDOW_NORMAL) 
cv2.imshow("Ventana", img)
cv2.waitKey()
cv2.destroyAllWindows()
