# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 07:56:44 2026

@author: migue
"""
#grabamos lo que se vera en la camara, para con ayuda de la voz dira cuando se este iniciando la grabacion y cuando termine

import pyttsx3
import cv2
import datetime

hoy = datetime.datetime.second
voz = pyttsx3.init()
voces = voz.getProperty('voices')
voz.setProperty('rate',100)
voz.setProperty('volume',1)
voz.setProperty('voice', voces[2].id)
voz.say("Grabacion Iniciada")
camara = cv2.VideoCapture(0)
salida = cv2.VideoWriter('video'+str(hoy)+'.avi',
                         cv2.VideoWriter_fourcc(*'XVID'), #Grabar lo de la camara
                         20.0,(640,480))
while(camara.isOpened()):
    f, frame = camara.read()
    if f == True:
        frame = cv2.flip(frame, 1) # camniar el espejo de la camara
        cv2.imshow("Frame", frame)
        salida.write(frame) #Guardar lo que se grabo
        key = cv2.waitKey(1)
        if key == ord('a'):
            voz.say("Grabacion Terminada")
            voz.runAndWait()
            break
    else:
        break
camara.release()
salida.release()
cv2.destroyAllWindows()