# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 08:18:47 2026

@author: migue
"""

#LEER EN VOZ 
import pyttsx3

voz = pyttsx3.init()
voces = voz.getProperty('voices')
voz.setProperty('rate',100)
voz.setProperty('volume',1)
voz.setProperty('voice', voces[0].id)
hablar = input ("Escribe la palabra a frase a decir: ")
voz.say(hablar)
voz.runAndWait()