# -*- coding: utf-8 -*-
"""
Created on Thu Feb 26 07:31:53 2026

@author: migue
"""

# Deteccion de objetos mediante su centro
#Objetos de diferentes contornos

import cv2
import easygui as vent
import numpy as np
imagen = vent.fileopenbox(msg="Abrir Imagen", title="Abrir",  #ABRIR EXPLORADOR PARA CARGAR LA IMAGEN
                           default="", filetypes=["*.jpg"])

img = cv2.imread(imagen)
#CAMBIAR TAMAÑO DE LA IMAGEN
img = cv2.resize(img, (600,600))
alto, ancho, _ = img.shape

copia = img.copy()
copia = cv2.cvtColor(copia, cv2.COLOR_BGR2GRAY) #PONER IMAGEN A ESCALA DE GRISES
imgmedian = cv2.medianBlur(copia, 5)

_, valor = cv2.threshold(copia, 240, 255, cv2.THRESH_BINARY)##### ESTE EL KERNEL EL GAUSSIANBLUR Y AREA LISTA SE MUEVEN
kernel = np.ones((3,3),np.uint8) #Buscara la figura del objeto
figura = cv2.morphologyEx(valor, cv2.MORPH_CLOSE, kernel) #Morfologia
#bordes = cv2.Canny(figura,3,3)
contornos, _ = cv2.findContours(figura,
                                cv2.RETR_TREE,
                                cv2.CHAIN_APPROX_SIMPLE) #Generar contornos

print(len(contornos))
lista = []
for i in range(len(contornos)):
    area = cv2.contourArea(contornos[i])
    if area > 1000 and area < 308801:
        lista.append(area)
        print(f'Area: {area}')
        cv2.drawContours(img, contornos, i, (255,0,0),10)
        objeto = contornos[i]
        M = cv2.moments(objeto)
        if M['m00'] != 0:
            cx = int(M['m10']/M['m00'])
            cy = int(M['m01']/M['m00'])
            img = cv2.circle(img, (cx,cy), radius=1, color=(0,255,0),thickness=1)
            cv2.drawContours(img, contornos, i, (0,0,255),10)
            #TEXTO AREAS
            img = cv2.putText(img, "Centro: "+str(area),(cx,cy),
                              cv2.FONT_HERSHEY_SIMPLEX,
                              1,(0,255,0),2,cv2.LINE_AA)

cv2.putText(img, "N Objetos:"+str(len(lista)),(25,25),cv2.FONT_HERSHEY_SIMPLEX,1,(255,0,0),2,cv2.LINE_AA)

cv2.namedWindow("Copia",cv2.WINDOW_NORMAL) 
cv2.imshow("Copia", figura)

cv2.namedWindow("Ventana",cv2.WINDOW_NORMAL) 
cv2.imshow("Ventana", img)
cv2.waitKey()
cv2.destroyAllWindows()